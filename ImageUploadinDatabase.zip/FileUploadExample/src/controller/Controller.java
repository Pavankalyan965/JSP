package controller;


import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.io.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import dao.Dao;
import model.Model;

@WebServlet("/reqreg")
public class Controller extends HttpServlet
{
	private final String upload_dir = "F://cloud9";
	public void doPost(HttpServletRequest req,HttpServletResponse res)
	{
		Model m=new Model();
		if(ServletFileUpload.isMultipartContent(req))
		{
			
            try {
                List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(req);
              
                for(FileItem item : multiparts)
                {
                    if(!item.isFormField())
                    {
                        String name = new File(item.getName()).getName();
                        item.write( new File(upload_dir + File.separator + name));
                      m.setPhoto(name);
                    }
                    else
                    {
              
                    	if(item.getFieldName().equals("t1"))
                    	{
                    		m.setName(item.getString());
                    	}
                    	else if(item.getFieldName().equals("t2"))
                    	{
                    		m.setEmail(item.getString());
                    	}
                    	else if(item.getFieldName().equals("t4"))
                    	{
                    		m.setMobile(Long.parseLong(item.getString()));
                    	}
                    
           
                    	
                    	
                    }
                }
                new Dao().register(m);
            }
                catch(Exception e)
                {
                	System.out.println(e);
                	
                }
            }
	}}
           


