package controller;

import java.io.File;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.*;
import java.io.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@WebServlet("/reqreg")
public class Controller extends HttpServlet
{
	private final String upload_dir= "F://cloud";
	public void doPost(HttpServletRequest req,HttpServletResponse res)
	{
		if(ServletFileUpload.isMultipartContent(req))
		{
			try
			{
				List<FileItem>multiparts= new ServletFileUpload(new DiskFileItemFactory()).parseRequest(req);
				for(FileItem item:multiparts)
				{
					if(!item.isFormField())
					{
						String name=new File(item.getName()).getName();
						item.write(new File(upload_dir + File.separator + name));
						System.out.println("Fname: "+name);
					}
					else
					{
						System.out.println("Item value "+item.getString());
					}
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}
}
