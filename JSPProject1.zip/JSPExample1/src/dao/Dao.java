package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Login;
import model.User;

public class Dao 
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try
		{
		Class.forName("org.h2.Driver");
		con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/dao","dao","dao");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
	public boolean login(Login l) throws SQLException
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		Statement stmt=con.createStatement();
		try
		{
			ResultSet rs=stmt.executeQuery("select uname,pwd from login where uname='"+l.getUname()+"' and pwd='"+l.getPwd()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean register(User u) throws SQLException
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		ResultSet rs=null;
		try
		{
		PreparedStatement ps=con.prepareStatement("insert into jspuser values(?,?,?,?,?)");
		ps.setString(1, u.getUname());
		ps.setString(2, u.getPwd());
		ps.setString(3, u.getEmail());
		ps.setLong(4, u.getMobile());
		ps.setString(5, u.getCity());
		int i=ps.executeUpdate();
		if(i>0)
		{
			b=true;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<User> viewAllUsers()
	{
		ArrayList<User> al=new ArrayList<User>();
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select * from jspuser");
			while(rs.next())
			{
				User u=new User();
				u.setUname(rs.getString(1));
				u.setPwd(rs.getString(2));
				u.setEmail(rs.getString(3));
				u.setMobile(Long.parseLong(rs.getString(4)));
				u.setCity(rs.getString(5));
				al.add(u);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return al;
	}
	public ResultSet update(User u)
	{
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from jspuser where email='"+u.getEmail()+"'");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return rs;
	}
	public boolean updateuserdetails(User u)
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			int i=stmt.executeUpdate("update jspuser set uname='"+u.getUname()+"',pwd='"+u.getPwd()+"',mobile='"+u.getMobile()+"',city='"+u.getCity()+"' where email='"+u.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean deleteuser(User u) 
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		try
		{	
			Statement stmt=con.createStatement();
			int i=stmt.executeUpdate("delete from jspuser where email='"+u.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	
}
