package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import model.Login;
import model.User;

@WebServlet(urlPatterns= {"/reqlogin","/reqallusers","/reqreg","/requpdate","/requpdateuserdetails","/reqdelete"})

public class Controller extends HttpServlet 
{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		String path=req.getServletPath();
		PrintWriter out=res.getWriter();
		if(path.equals("/reqlogin"))
		{
			String uname=req.getParameter("t1");
			String pwd=req.getParameter("t2");
			Login l=new Login();
			l.setUname(uname);
			l.setPwd(pwd);
			boolean b;
			try {
				b = new Dao().login(l);
			if(b)
			{
			    RequestDispatcher rd=req.getRequestDispatcher("welcome.jsp");
			    rd.forward(req, res);
				
			}
			else
			{
			    RequestDispatcher rd=req.getRequestDispatcher("welcome.jsp");
			    rd.include(req, res);
			    out.print("<body><center>Invalid username/password");
			}
			}
			catch (SQLException e) 
			{
				System.out.println(e);
			}
				
		}
		else if(path.equals("/reqreg"))
		{
			User u=new User();
			u.setUname(req.getParameter("t1"));
			u.setPwd(req.getParameter("t2"));
			u.setEmail(req.getParameter("t3"));
			u.setMobile(Long.parseLong(req.getParameter("t4")));
			u.setCity(req.getParameter("t5"));
			try
			{
				boolean b=new Dao().register(u);
				if(b)
				{
					RequestDispatcher rd=req.getRequestDispatcher("login.jsp");
					rd.forward(req, res);
				}
				else
				{
					RequestDispatcher rd=req.getRequestDispatcher("register.jsp");
					rd.include(req, res);
				}
			} 
			catch (SQLException e)
			{
				System.out.println(e);
			}
		}
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		String path=req.getServletPath();
		PrintWriter out=res.getWriter();
		User u=new User();
		if(path.equals("/reqallusers"))
		{
			ArrayList<User> al=new ArrayList<User>();
			al=new Dao().viewAllUsers();
			req.setAttribute("users", al);
			RequestDispatcher rd=req.getRequestDispatcher("ViewAllUsers.jsp");
			rd.forward(req, res);
		}
		else if(path.equals("/requpdate"))
		{
			ResultSet rs=null;
			u.setEmail(req.getParameter("id"));
			rs=new Dao().update(u);
			try
			{
				if(rs.next())
				{
					out.print("<body bgcolor=DACBC9><center><br><br><form action=requpdateuserdetails><table border=3>");
					out.print("<tr><td>Name :</td><td> <input type=text name=t1 value="+rs.getString(1)+"></td></tr>");
					out.print("<tr><td>Passwod :</td><td> <input type=text name=t2 value="+rs.getString(2)+"></td></tr>");
					out.print("<tr><td>email :</td><td> <input type=text readonly name=t3 value="+rs.getString(3)+"></td></tr>");
					out.print("<tr><td>Mobile :</td><td> <input type=text  name=t4 value="+rs.getLong(4)+"></td></tr>");
					out.print("<tr><td>City :</td><td> <input type=text  name=t5 value="+rs.getString(5)+"></td></tr>");
					out.print("<tr><td><input type=submit value=Update></td><td> <input type=reset value=Clear></td></tr></table></form>");
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		else if(path.equals("/requpdateuserdetails"))
		{
			u.setUname(req.getParameter("t1"));
			u.setPwd(req.getParameter("t2"));
			u.setEmail(req.getParameter("t3"));
			u.setMobile(Long.parseLong(req.getParameter("t4").trim()));
			u.setCity((req.getParameter("t5")));
			boolean b=new Dao().updateuserdetails(u);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
				rd.forward(req, res);
			}
			else
			{
				out.print("failed");
			}
		}
		else if(path.equals("/reqdelete"))
		{
			u.setEmail(req.getParameter("id"));
			boolean b=new Dao().deleteuser(u);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
				rd.forward(req, res);
			}
			else
			{
				out.print("failed");
			}
		}
		
	}
}
